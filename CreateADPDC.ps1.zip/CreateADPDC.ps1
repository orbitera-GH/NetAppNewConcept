﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InteraceAlias=$($Interface.Name)

Set-ExecutionPolicy RemoteSigned -Force
C:\Packages\Plugins\Microsoft.Powershell.DSC\1.7.0.0\DSCWork\CreateADPDC.ps1.0\stawiacz.ps1 > C:\Windows\Temp\stawiaczLog.txt
echo "start sleep"	> C:\Windows\Temp\start-sleep.txt
start-sleep -s 60
echo "stop sleep"	> C:\Windows\Temp\stop-sleep.txt

    Node localhost
    {
         
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }
        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }
        LocalConfigurationManager 
        {
            ActionAfterReboot = 'StopConfiguration'
        }
   }
} 