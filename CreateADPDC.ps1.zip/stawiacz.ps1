#set containerName = test123i12345
#set storageName = scalearc1d
#set storageKey = uxpHwTzlz3LuxKswO73lWtfeN/Wt3+8e1GKJNEy3S4023050J+VzAMfd1gjfG259r7Un7EHH9jJNmhrENKjkzw==
#numer TD z hostname stawiacza, stala czes to "st-"
#%1 - resourceGroupName
#%2 - HostName
#%3 - Location
#%4 - OsDisk
#%5 - DataDisk
#%6 - containerName
#%7 - NicCard

$txt=Get-Childitem env:computername | select value -ExpandProperty value
$TestdriveID=$txt.TrimStart("ST-")
$resourceGroupName="orbiteratestdrive"+$TestdriveID
$HostName="PDC-"+$TestdriveID
$location="westeurope"
$OsDisk="https://scalearc1td.blob.core.windows.net/fvhds/PDC-scalearc.vhd"
$DataDisk = "https://scalearc1td.blob.core.windows.net/fvhds/PDC-data-1.vhd"
$NicCard = "PDC-nic"
import-module azure
$containerName = $TestdriveID
$StorageAccountKey = "uxpHwTzlz3LuxKswO73lWtfeN/Wt3+8e1GKJNEy3S4023050J+VzAMfd1gjfG259r7Un7EHH9jJNmhrENKjkzw=="
$StorageAccount = "scalearc1td"
$rawContainer = "fvhdsraw"
$login="john@orbitera.onmicrosoft.com"
$password="BXD01test"
$credentials=(New-Object System.Management.Automation.PSCredential("$login",(ConvertTo-SecureString $password -AsPlainText -Force)))
$context = New-AzureStorageContext -StorageAccountName $StorageAccount -StorageAccountKey $StorageAccountKey

$sourceURI = "https://scalearc1td.blob.core.windows.net/fvhdsraw/PDC-scalearc.vhd"
$dest_blobName ="PDC-scalearc.vhd"
$sourceURI1 = "https://scalearc1td.blob.core.windows.net/fvhdsraw/PDC-data-1.vhd"
$dest_blobName1 ="PDC-data-1.vhd"

Add-AzureAccount -Credential $credentials
Switch-AzureMode AzureResourceManager
New-AzureStorageContainer $containerName -Context $context
$blobCopy1 = Start-AzureStorageBlobCopy -SrcUri $sourceURI1 -SrcContext $context -DestContainer $containerName -DestBlob $dest_blobName1 -DestContext $context
$blobCopy = Start-AzureStorageBlobCopy -SrcUri $sourceURI -SrcContext $context -DestContainer $containerName -DestBlob $dest_blobName -DestContext $context

while(($blobCopy | Get-AzureStorageBlobCopyState).Status -eq "Pending") {
		Start-Sleep -s 15
		$blobCopy | Get-AzureStorageBlobCopyState
}
New-AzureResourceGroup -Name $resourceGroupName -Location $location
C:\Windows\System32\cmd.exe /E:ON /V:ON /C "C:\Packages\Plugins\Microsoft.Powershell.DSC\1.7.0.0\DSCWork\CreateADPDC.ps1.0\azcli.cmd $resourceGroupName $HostName $Location $OsDisk $DataDisk $containerName $NicCard"

